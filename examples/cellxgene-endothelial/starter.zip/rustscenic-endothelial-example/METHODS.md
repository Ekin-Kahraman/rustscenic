# Methods and file guide

## Fixed analysis plan

The original denominator is 704 human Cell Ontology labels in Census 2025-11-08,
each with at least 1,000 primary cells after requiring at least 200 detected
genes per cell. Cells span tissue and disease annotations. The resource does
not restrict these cohorts to healthy donors or one tissue.

Each cohort selects up to 5,000 cells balanced by dataset and donor with seed
777. The selected metadata and input integrity were checked privately. The
number of cell slots summed across cohorts is an analysis count, not a claim
that all eligible Census cells were fitted.

Inference uses RustScenic 0.5.0, Census API 1.18.0, four worker CPUs and
`feature_policy=pooled_expression`. Effective gene/TF selection is recorded in
each cohort's feature metadata and `gene_universe.parquet`. Historical
`n_hvg=2000` and `n_tfs=256` fields are not active feature caps for this policy.
Expression is normalised to a library size of 10,000 and log1p transformed.

The model profile uses a 5,000-estimator ceiling with early-stop window 25,
learning rate 0.01, depth 3, max_features 0.1 and subsample 0.9. Retained GRNs
contain up to 200 targets per TF. The ceiling is not a statement that every
target fit used 5,000 trees. The original manifest preserves exact settings.

Candidate target sets use expression-correlation signs and the recorded
rho threshold of 0.03. Motif pruning uses the pinned human cisTarget v10
references. Evidence retains motif enrichment scores, with NES >= 3 checked
by the independent auditor. AUCell uses a 0.05 top fraction of the full
measured gene universe, with the exact cutoff in per-cohort metadata.

## Files within each cohort

| Artifact | Interpretation |
| --- | --- |
| `grn.parquet` | Retained TF–target importance scores before motif pruning. |
| `grn_signed.parquet` | Retained edges with expression correlation and sign labels. |
| `candidate_regulons.json` | Candidate signed target sets before motif filtering. |
| `regulons.json` | Motif-supported target sets from the pooled run. |
| `motif_support.parquet` | Motif enrichment evidence for target sets. |
| `aucell_summary.parquet` | Activity mean, spread, quantiles and nonzero fraction. |
| `gene_universe.parquet` | Measured genes, inference-feature flags and AUCell universe. |
| `metadata.json` | Original analysis/configuration identity, aggregate selection and file hashes. |
| `sources.json` | Selected-cell counts per dataset and source-representation labels. |

The original inference artifact bytes are retained. Packaged metadata removes
the cell-level artifact entry, adds the original private metadata hash and uses
a package schema label. Original private metadata and selected-cell artifacts
remain in the audited return archive. Source-snapshot files are unchanged.

## Checks performed and their limits

The private content audit checked all original artifact hashes and sizes,
plan/configuration/source identities, cell uniqueness, ontology and QC, sample
counts, balancing-stratum counts, citations, gene/TF universes, finite network
scores, target caps, signed-edge consistency, regulon membership, motif support,
activity ranges/quantiles/shapes and timings. Its report is included under
`provenance/output-content-audit.json`.

The package verifier independently checks the delivered inventory and reuse
metadata. It cannot repeat input checks because private cell-level inputs are
excluded. Neither audit refits GRNs or establishes biological accuracy.
Primary-cell status is supported by the frozen query; the private selected-cell
table does not retain `is_primary_data`. Full reconstruction of balanced
selection would require the original candidate-cell inventory.

Each cohort has one seed and one pooled run. Donor labels are dataset scoped;
they do not independently establish unique donors across studies. Assay,
study, tissue and disease mixture can influence the networks. The source labels
describe representation, not validation. No selective removal of weak or
single-source networks is performed.
